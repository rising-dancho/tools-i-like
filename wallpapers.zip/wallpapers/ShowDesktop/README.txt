https://chatgpt.com/share/683af4c9-b24c-8000-90f4-3ebf6743c0c3
https://github.com/Makazzz/BatToExePortable/releases/tag/3.1.99.1